export const CREATE_NEW_MESSAGE = "CREATE_NEW_MESSAGE";
export const GET_ALL_MESSAGE = 'GET_ALL_MESSAGE';

// export const 
// export const 
// export const 
// export const 