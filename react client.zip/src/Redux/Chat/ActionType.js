export const CREATE_SINGLE_CHAT = "CREATE_SINGLE_CHAT";
export const GET_ALL_CHAT = 'GET_ALL_CHAT';
export const CREATE_GROUP_CHAT="CREATE_GROUP_CHAT";

// export const 
// export const 
// export const 
// export const 