package com.zos.exception;

public class ChatException extends Exception {

	public ChatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
