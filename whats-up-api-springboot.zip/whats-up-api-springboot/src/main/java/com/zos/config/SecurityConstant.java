package com.zos.config;

public class SecurityConstant {
	
	public static final String JWT_KEY="kzjjbeiurbZGyurZvzpaqekmeecfeeljliuogcerwmqzsduphbeheb";
	public static final String HEADER = "Authorization";


}
