package com.learner.service;

import java.util.List;

import com.learner.exception.ChatException;
import com.learner.exception.MessageException;
import com.learner.exception.UserException;
import com.learner.modal.Message;
import com.learner.request.SendMessageRequest;

public interface MessageService  {
	
	public Message sendMessage(SendMessageRequest req) throws UserException, ChatException;
	
	public List<Message> getChatsMessages(Integer chatId) throws ChatException;
	
	public Message findMessageById(Integer messageId) throws MessageException;
	
	public String deleteMessage(Integer messageId) throws MessageException;

}
